package com.visiontune.app

data class FrameStats(val fps: Double, val jankPercent: Double, val sampleCount: Int)

/**
 * Parses the output of `dumpsys gfxinfo <package> framestats`, which is
 * the real, system-level frame-timing data Android itself records for the
 * foreground app - this is what makes the FPS/jank numbers genuine instead
 * of invented.
 */
object FrameStatsParser {

    private const val SECTION_MARKER = "---PROFILEDATA---"

    fun parse(raw: String, refreshHz: Double = 60.0): FrameStats? {
        val startIdx = raw.indexOf(SECTION_MARKER)
        if (startIdx == -1) return null
        val afterStart = raw.substring(startIdx + SECTION_MARKER.length)
        val endIdx = afterStart.indexOf(SECTION_MARKER)
        val block = if (endIdx != -1) afterStart.substring(0, endIdx) else afterStart

        val lines = block.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return null

        val header = lines.first().split(",")
        val vsyncIdx = header.indexOfFirst { it.equals("Vsync", ignoreCase = true) }
        val flagsIdx = header.indexOfFirst { it.equals("Flags", ignoreCase = true) }
        if (vsyncIdx == -1) return null

        val vsyncTimes = mutableListOf<Long>()
        for (line in lines.drop(1)) {
            val cols = line.split(",")
            if (cols.size <= vsyncIdx) continue
            val flags = cols.getOrNull(flagsIdx)?.toLongOrNull() ?: 0L
            if (flags != 0L) continue // skip incomplete/invalid frames
            val vsync = cols[vsyncIdx].toLongOrNull() ?: continue
            vsyncTimes.add(vsync)
        }
        if (vsyncTimes.size < 2) return null
        vsyncTimes.sort()

        val intervalsNs = vsyncTimes.zipWithNext { a, b -> b - a }.filter { it > 0 }
        if (intervalsNs.isEmpty()) return null

        val avgIntervalNs = intervalsNs.average()
        val fps = 1_000_000_000.0 / avgIntervalNs
        val targetFrameNs = 1_000_000_000.0 / refreshHz
        val jankFrames = intervalsNs.count { it > targetFrameNs * 1.5 }
        val jankPercent = 100.0 * jankFrames / intervalsNs.size

        return FrameStats(fps = fps, jankPercent = jankPercent, sampleCount = intervalsNs.size)
    }
}
