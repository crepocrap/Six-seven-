package com.visiontune.app

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Thin wrapper around Shizuku so the rest of the app doesn't touch the
 * Shizuku-API directly.
 *
 * NOTE: Shizuku's process API has changed across library versions. The
 * reflective call to `Shizuku.newProcess(...)` below is the classic
 * shell-exec entry point most Shizuku-powered open-source apps use. If
 * Gradle resolves a Shizuku-API version where that method's signature
 * moved, this is the one spot in the whole project you will likely need
 * to adjust - check https://github.com/RikkaApps/Shizuku-API for the
 * current signature. Everything else in this project does not depend on
 * unstable/undocumented APIs.
 */
object ShizukuBridge {

    const val REQUEST_CODE = 9001

    fun isAvailable(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    fun hasPermission(): Boolean {
        if (!isAvailable()) return false
        return try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Throwable) {
            false
        }
    }

    fun requestPermission() {
        if (isAvailable() && !hasPermission()) {
            try {
                Shizuku.requestPermission(REQUEST_CODE)
            } catch (e: Throwable) {
                // Shizuku not ready yet - ignore, user can retry.
            }
        }
    }

    /** Runs a shell command with Shizuku's (adb-shell-level) privileges.
     *  Returns stdout, or null if Shizuku isn't ready/permitted/failed. */
    fun runShellCommand(vararg command: String): String? {
        if (!hasPermission()) return null
        return try {
            val method = Shizuku::class.java.getMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            val process = method.invoke(null, command, null, null) ?: return null
            val getInputStream = process.javaClass.getMethod("getInputStream")
            val inputStream = getInputStream.invoke(process) as java.io.InputStream
            BufferedReader(InputStreamReader(inputStream)).use { it.readText() }
        } catch (e: Throwable) {
            null
        }
    }
}
