package com.visiontune.app

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class AppPickerActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_picker)

        val pm = packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcherIntent, PackageManager.MATCH_ALL)
            .map { it.activityInfo }
            .distinctBy { it.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        findViewById<ListView>(R.id.appPickerList).adapter =
            AppListAdapter(this, apps, pm) { info ->
                setResult(
                    RESULT_OK,
                    Intent().apply {
                        putExtra(RESULT_PACKAGE, info.packageName)
                        putExtra(RESULT_LABEL, info.loadLabel(pm).toString())
                    }
                )
                finish()
            }
    }

    companion object {
        const val RESULT_PACKAGE = "result_package"
        const val RESULT_LABEL = "result_label"
    }
}
