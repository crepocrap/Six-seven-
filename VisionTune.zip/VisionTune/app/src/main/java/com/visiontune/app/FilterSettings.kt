package com.visiontune.app

/**
 * saturation: 0-100 (100 = unchanged). Can only be REDUCED by an overlay,
 *             never boosted past the original - see FilterOverlayView.
 * exposure:   -100..100 (0 = unchanged). Negative darkens, positive brightens.
 * shadow:     0-100. Darkens the edges of the screen (vignette).
 * clarity:    0-100. "Clarity Boost" perceptual sharpness illusion (not real
 *             upscaling/sharpening - see FilterOverlayView for why).
 */
data class FilterSettings(
    val saturation: Int = 100,
    val exposure: Int = 0,
    val shadow: Int = 0,
    val clarity: Int = 0
)
