package com.visiontune.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private var selectedPackage: String? = null

    private lateinit var shizukuStatus: TextView
    private lateinit var selectedAppLabel: TextView
    private lateinit var managedAppsList: ListView
    private lateinit var saturationSeek: SeekBar
    private lateinit var exposureSeek: SeekBar
    private lateinit var shadowSeek: SeekBar
    private lateinit var claritySeek: SeekBar

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { _, grantResult ->
        refreshShizukuStatus()
        if (grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            SystemColorCorrection.grantWriteSecureSettings(this)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        shizukuStatus = findViewById(R.id.shizukuStatus)
        selectedAppLabel = findViewById(R.id.selectedAppLabel)
        managedAppsList = findViewById(R.id.managedAppsList)
        saturationSeek = findViewById(R.id.saturationSeek)
        exposureSeek = findViewById(R.id.exposureSeek)
        shadowSeek = findViewById(R.id.shadowSeek)
        claritySeek = findViewById(R.id.claritySeek)

        runCatching { Shizuku.addRequestPermissionResultListener(permissionListener) }

        findViewById<Button>(R.id.requestShizukuButton).setOnClickListener {
            if (!ShizukuBridge.isAvailable()) {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/")))
            } else {
                ShizukuBridge.requestPermission()
            }
        }

        findViewById<Button>(R.id.overlayPermissionButton).setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }

        findViewById<Button>(R.id.accessibilityPermissionButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.addAppButton).setOnClickListener {
            startActivityForResult(Intent(this, AppPickerActivity::class.java), REQ_PICK_APP)
        }

        findViewById<Button>(R.id.refreshListButton).setOnClickListener { refreshManagedAppsList() }
        findViewById<Button>(R.id.applyButton).setOnClickListener { applyToSelected() }

        findViewById<Button>(R.id.startBenchmarkButton).setOnClickListener {
            val pkg = selectedPackage
            if (pkg == null) {
                selectedAppLabel.text = getString(R.string.no_app_selected)
            } else {
                startService(
                    Intent(this, BenchmarkOverlayService::class.java)
                        .putExtra(BenchmarkOverlayService.EXTRA_PACKAGE, pkg)
                )
            }
        }
        findViewById<Button>(R.id.stopBenchmarkButton).setOnClickListener {
            stopService(Intent(this, BenchmarkOverlayService::class.java))
        }

        managedAppsList.setOnItemClickListener { _, _, position, _ ->
            val app = TargetAppStore.getAll(this).getOrNull(position) ?: return@setOnItemClickListener
            selectedPackage = app.packageName
            selectedAppLabel.text = getString(R.string.editing_app, app.label)
            saturationSeek.progress = app.saturation
            exposureSeek.progress = app.exposure + 100
            shadowSeek.progress = app.shadow
            claritySeek.progress = app.clarity
        }

        refreshManagedAppsList()
        refreshShizukuStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshShizukuStatus()
    }

    private fun applyToSelected() {
        val pkg = selectedPackage ?: return
        val existing = TargetAppStore.find(this, pkg) ?: return
        existing.saturation = saturationSeek.progress
        existing.exposure = exposureSeek.progress - 100
        existing.shadow = shadowSeek.progress
        existing.clarity = claritySeek.progress
        TargetAppStore.update(this, existing)

        // Live-preview immediately instead of waiting for the app to reopen.
        startService(
            Intent(this, OverlayFilterService::class.java)
                .putExtra(OverlayFilterService.EXTRA_SATURATION, existing.saturation)
                .putExtra(OverlayFilterService.EXTRA_EXPOSURE, existing.exposure)
                .putExtra(OverlayFilterService.EXTRA_SHADOW, existing.shadow)
                .putExtra(OverlayFilterService.EXTRA_CLARITY, existing.clarity)
        )
    }

    private fun refreshManagedAppsList() {
        val apps = TargetAppStore.getAll(this)
        managedAppsList.adapter =
            ArrayAdapter(this, android.R.layout.simple_list_item_1, apps.map { it.label })
    }

    private fun refreshShizukuStatus() {
        shizukuStatus.text = when {
            !ShizukuBridge.isAvailable() -> getString(R.string.shizuku_not_installed)
            ShizukuBridge.hasPermission() -> getString(R.string.shizuku_granted)
            else -> getString(R.string.shizuku_not_granted)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK_APP && resultCode == RESULT_OK) {
            val pkg = data?.getStringExtra(AppPickerActivity.RESULT_PACKAGE) ?: return
            val label = data.getStringExtra(AppPickerActivity.RESULT_LABEL) ?: pkg
            TargetAppStore.add(this, ManagedApp(pkg, label))
            refreshManagedAppsList()
        }
    }

    override fun onDestroy() {
        runCatching { Shizuku.removeRequestPermissionResultListener(permissionListener) }
        super.onDestroy()
    }

    companion object {
        private const val REQ_PICK_APP = 100
    }
}
