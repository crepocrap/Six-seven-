package com.visiontune.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.NotificationCompat

class OverlayFilterService : Service() {

    private lateinit var windowManager: WindowManager
    private var overlayView: FilterOverlayView? = null

    companion object {
        const val CHANNEL_ID = "visiontune_overlay"
        const val EXTRA_SATURATION = "saturation"
        const val EXTRA_EXPOSURE = "exposure"
        const val EXTRA_SHADOW = "shadow"
        const val EXTRA_CLARITY = "clarity"
        const val ACTION_STOP = "com.visiontune.app.STOP_FILTER"

        @Volatile var isRunning = false
            private set
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopOverlay()
            stopSelf()
            return START_NOT_STICKY
        }

        startForegroundWithNotification()
        if (overlayView == null) addOverlay()

        overlayView?.settings = FilterSettings(
            saturation = intent?.getIntExtra(EXTRA_SATURATION, 100) ?: 100,
            exposure = intent?.getIntExtra(EXTRA_EXPOSURE, 0) ?: 0,
            shadow = intent?.getIntExtra(EXTRA_SHADOW, 0) ?: 0,
            clarity = intent?.getIntExtra(EXTRA_CLARITY, 0) ?: 0
        )
        isRunning = true
        return START_STICKY
    }

    private fun addOverlay() {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START

        val view = FilterOverlayView(this)
        windowManager.addView(view, params)
        overlayView = view
    }

    private fun stopOverlay() {
        overlayView?.let { runCatching { windowManager.removeView(it) } }
        overlayView = null
        isRunning = false
    }

    private fun startForegroundWithNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "VisionTune Filter", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.filter_active))
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
        startForeground(1, notification)
    }

    override fun onDestroy() {
        stopOverlay()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
