package com.visiontune.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Watches only which app is currently in the foreground (it never reads
 * on-screen content - canRetrieveWindowContent is false in the config).
 * When the foreground app matches one on the user's managed list, it
 * starts the filter overlay with that app's saved settings; otherwise it
 * stops the overlay. This is the "it shows up automatically when you open
 * the app" behaviour that was asked for.
 */
class ForegroundAppWatcherService : AccessibilityService() {

    private var activeFilterPackage: String? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == activeFilterPackage) return

        val managed = TargetAppStore.find(this, pkg)
        if (managed != null) {
            activeFilterPackage = pkg
            startService(
                Intent(this, OverlayFilterService::class.java)
                    .putExtra(OverlayFilterService.EXTRA_SATURATION, managed.saturation)
                    .putExtra(OverlayFilterService.EXTRA_EXPOSURE, managed.exposure)
                    .putExtra(OverlayFilterService.EXTRA_SHADOW, managed.shadow)
                    .putExtra(OverlayFilterService.EXTRA_CLARITY, managed.clarity)
            )
        } else if (activeFilterPackage != null) {
            activeFilterPackage = null
            startService(Intent(this, OverlayFilterService::class.java).apply {
                action = OverlayFilterService.ACTION_STOP
            })
        }
    }

    override fun onInterrupt() {}
}
