package com.visiontune.app

import android.content.Context

data class ManagedApp(
    val packageName: String,
    val label: String,
    var saturation: Int = 100,
    var exposure: Int = 0,
    var shadow: Int = 0,
    var clarity: Int = 0
)

/** Simple SharedPreferences-backed store for the user's managed app list. */
object TargetAppStore {
    private const val PREFS = "visiontune_apps"

    fun getAll(context: Context): MutableList<ManagedApp> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getStringSet("packages", emptySet()) ?: emptySet()
        return raw.mapNotNull { entry ->
            val p = entry.split("|")
            if (p.size < 6) return@mapNotNull null
            ManagedApp(
                packageName = p[0], label = p[1],
                saturation = p[2].toIntOrNull() ?: 100,
                exposure = p[3].toIntOrNull() ?: 0,
                shadow = p[4].toIntOrNull() ?: 0,
                clarity = p[5].toIntOrNull() ?: 0
            )
        }.toMutableList()
    }

    fun saveAll(context: Context, apps: List<ManagedApp>) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val encoded = apps.map {
            "${it.packageName}|${it.label}|${it.saturation}|${it.exposure}|${it.shadow}|${it.clarity}"
        }.toSet()
        prefs.edit().putStringSet("packages", encoded).apply()
    }

    fun add(context: Context, app: ManagedApp) {
        val all = getAll(context)
        if (all.none { it.packageName == app.packageName }) {
            all.add(app)
            saveAll(context, all)
        }
    }

    fun update(context: Context, app: ManagedApp) {
        val all = getAll(context)
        val idx = all.indexOfFirst { it.packageName == app.packageName }
        if (idx >= 0) {
            all[idx] = app
            saveAll(context, all)
        }
    }

    fun remove(context: Context, packageName: String) {
        saveAll(context, getAll(context).filter { it.packageName != packageName })
    }

    fun find(context: Context, packageName: String): ManagedApp? =
        getAll(context).firstOrNull { it.packageName == packageName }
}
