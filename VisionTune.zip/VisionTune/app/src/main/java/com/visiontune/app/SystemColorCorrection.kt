package com.visiontune.app

import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings

/**
 * A real, documented Android accessibility feature ("Color correction" in
 * Settings > Accessibility), toggled here instead of by hand. Because it's
 * applied by the display pipeline itself, it costs ~0 extra render time -
 * but it only offers a few FIXED presets (grayscale / colorblind-assist
 * modes), not continuous custom saturation/contrast sliders. That ceiling
 * is a real OS limitation, not something this app can work around without
 * root.
 */
object SystemColorCorrection {

    fun grantWriteSecureSettings(context: Context): Boolean {
        val pkg = context.packageName
        val result = ShizukuBridge.runShellCommand(
            "pm", "grant", pkg, "android.permission.WRITE_SECURE_SETTINGS"
        )
        return result != null
    }

    fun hasWriteSecureSettings(context: Context): Boolean =
        context.checkSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) ==
            PackageManager.PERMISSION_GRANTED

    /** mode: 0=off, 1=protanomaly, 2=deuteranomaly, 3=tritanomaly, 4=grayscale
     *  (mode availability can vary slightly by OEM). */
    fun setDaltonizerMode(context: Context, enabled: Boolean, mode: Int = 4) {
        if (!hasWriteSecureSettings(context)) return
        Settings.Secure.putInt(
            context.contentResolver, "accessibility_display_daltonizer_enabled",
            if (enabled) 1 else 0
        )
        Settings.Secure.putInt(
            context.contentResolver, "accessibility_display_daltonizer", mode
        )
    }
}
