package com.visiontune.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat

class BenchmarkOverlayService : Service() {

    companion object {
        const val CHANNEL_ID = "visiontune_benchmark"
        const val EXTRA_PACKAGE = "target_package"
    }

    private lateinit var windowManager: WindowManager
    private var textView: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private var targetPackage: String = ""

    private val poller = object : Runnable {
        override fun run() {
            val raw = ShizukuBridge.runShellCommand("dumpsys", "gfxinfo", targetPackage, "framestats")
            val stats = raw?.let { FrameStatsParser.parse(it) }
            textView?.text = when {
                stats != null ->
                    "VisionTune · %s\n%.1f FPS  ·  Jank %.1f%%".format(
                        targetPackage.substringAfterLast('.'), stats.fps, stats.jankPercent
                    )
                ShizukuBridge.hasPermission() -> "VisionTune\nبانتظار بيانات الإطارات…"
                else -> "VisionTune\nفعّل صلاحية Shizuku لقراءة FPS حقيقي"
            }
            handler.postDelayed(this, 1500)
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        targetPackage = intent?.getStringExtra(EXTRA_PACKAGE) ?: packageName
        startForegroundWithNotification()
        if (textView == null) addOverlay()
        handler.removeCallbacks(poller)
        handler.post(poller)
        return START_STICKY
    }

    private fun addOverlay() {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.END
        params.x = 24
        params.y = 120

        val view = TextView(this).apply {
            setBackgroundColor(Color.argb(160, 0, 0, 0))
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(20, 14, 20, 14)
            text = "VisionTune\nReading frames…"
        }
        windowManager.addView(view, params)
        textView = view
    }

    private fun startForegroundWithNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "VisionTune Benchmark", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("VisionTune benchmark running")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
        startForeground(2, notification)
    }

    override fun onDestroy() {
        handler.removeCallbacks(poller)
        textView?.let { runCatching { windowManager.removeView(it) } }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
